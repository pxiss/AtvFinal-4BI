<?php
// Configuração do banco de dados
$host = 'localhost'; // Altere para o endereço do seu banco de dados, se necessário
$dbname = 'bd_schutzhtml'; // O nome do banco de dados
$username = 'root'; // Usuário do banco de dados (provavelmente 'root' no localhost)
$password = ''; // Senha do banco de dados (deixe em branco se não houver senha)

// Conectando ao banco de dados
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verifica se os dados foram enviados pelo método POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Sanitize os dados para evitar injeções de SQL
        $name = htmlspecialchars($_POST['name']);
        $email = htmlspecialchars($_POST['email']);
        $message = htmlspecialchars($_POST['message']);

        // Preparando a inserção no banco de dados
        $stmt = $pdo->prepare("INSERT INTO contatos (name, email, message) VALUES (:name, :email, :message)");
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':message', $message);
        $stmt->execute();

        // Redirecionando para uma página de confirmação ou exibindo uma mensagem de sucesso
        echo "Contato enviado com sucesso! Obrigado por entrar em contato.";
    }
} catch (PDOException $e) {
    // Se houver erro de conexão ou de execução no banco, exibimos uma mensagem de erro
    echo "Erro ao salvar os dados: " . $e->getMessage();
}
?>
